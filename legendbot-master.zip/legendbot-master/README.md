![Legend Bot](http://www.mayodev.com/images/legend.png)

# Legend Bot
Discord bot for tracking attacks and defenses in Legends League of Clash of Clans


